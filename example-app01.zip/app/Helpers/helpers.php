<?php

use App\Models\City;
use App\Models\State;
use App\Models\Country;

if (! function_exists('get_city')) {
    function get_city() {
        return City::all();
    }
}


if (! function_exists('get_state')) {
    function get_state() {
        return State::all();
    }
}


if (! function_exists('get_country')) {
    function get_country() {
        return Country::all();
    }
}
