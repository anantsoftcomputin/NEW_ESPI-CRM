@extends('layouts.app')

@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="alert alert-success" role="alert">
            <h4 class="alert-heading">Well done!</h4>
            <p>Submited</p>
            <hr>
            <p class="mb-0">Thanks For Submit.</p>
        </div>

    <a href="{{ url('/') }}" class="btn btn-info">Go Back</a>
    </div>

</div>
@endsection
