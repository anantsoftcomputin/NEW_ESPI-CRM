<?php

return [
    'top_menu' => "Applications"
];
